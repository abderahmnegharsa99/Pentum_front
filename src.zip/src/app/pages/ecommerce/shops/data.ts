const shopsData = [
    {
        title: 'Brendle\'s',
        poducts: 112,
        balance: '$13,575',
        color: 'primary'
    },
    {
        title: 'Tech Hifi',
        poducts: 104,
        balance: '$11,145',
        color: 'warning'
    },
    {
        title: 'Lafayette',
        poducts: 126,
        balance: '$12,356',
        color: 'danger'
    },
    {
        title: 'Packer',
        poducts: 102,
        balance: '$11,228',
        color: 'success'
    },
    {
        title: 'Nedick\'s',
        poducts: 96,
        balance: '$9,235',
        color: 'info'
    },
    {
        title: 'Hudson\'s',
        poducts: 120,
        balance: '$14,794',
        color: 'dark'
    },
    {
        title: 'Tech Hifi',
        poducts: 104,
        balance: '$11,145',
        color: 'dark'
    },
    {
        title: 'Brendle\'s',
        poducts: 112,
        balance: '$13,575',
        color: 'primary'
    },
    {
        title: 'Lafayette',
        poducts: 126,
        balance: '$12,356',
        color: 'success'
    },
];

export { shopsData };
