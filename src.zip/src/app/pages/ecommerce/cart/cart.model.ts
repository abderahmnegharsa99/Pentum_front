export interface Cart {
    id: any;
    image: string;
    name: string;
    color: string;
    price: number;
    qty: number;
    total: string;
}
