export interface Usergrid {
    id: number;
    image?: string;
    name: string;
    designation: string;
    projects: string[];
    email: string;
}
