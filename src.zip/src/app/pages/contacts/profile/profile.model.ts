// Chart data
export interface ChartType {
    chart?: any;
    plotOptions?: any;
    dataLabels?: any;
    stroke?: any;
    colors?: any;
    series?: any;
    fill?: any;
    xaxis?: any;
    yaxis?: any;
}
