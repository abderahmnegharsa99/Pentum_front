const userList = [
  {
    id: 1,
    name: "David McHenry",
    position: "UI/UX Designer",
    email: "david@skote.com",
    tags: ['Photoshop', 'illustrator'],
    project: "152",
    isSelected: false
  },
  {
    id: 2,
    profile: "assets/images/users/avatar-2.jpg",
    name: "Frank Kirk",
    position: "Frontend Developer",
    email: "frank@skote.com",
    tags: ['Html', 'Css', '2 + more'],
    project: "132",
    isSelected: false
  },
  {
    id: 3,
    profile: "assets/images/users/avatar-3.jpg",
    name: "Rafael Morales",
    position: "Backend Developer",
    email: "Rafael@skote.com",
    tags: ['Php', 'Java', 'Python'],
    project: "112",
    isSelected: false
  },
  {
    id: 4,
    name: "Mark Ellison",
    position: "Full Stack Developer",
    email: "mark@skote.com",
    tags: ['Ruby', 'Php', '2 + more'],
    project: "121",
    isSelected: false
  },
  {
    id: 5,
    profile: "assets/images/users/avatar-4.jpg",
    name: "Minnie Walter",
    position: "Frontend Developer",
    email: "minnie@skote.com",
    tags: ['Html', 'Css', '2 + more'],
    project: "145",
    isSelected: false
  },
  {
    id: 6,
    profile: "assets/images/users/avatar-5.jpg",
    name: "Shirley Smith",
    position: "UI/UX Designer",
    email: "shirley@skote.com",
    tags: ['Photoshop', 'illustrator'],
    project: "136",
    isSelected: false
  },
  {
    id: 7,
    name: "John Santiago",
    position: "Full Stack Developer",
    email: "john@skote.com",
    tags: ['Ruby', 'Php', '2 + more'],
    project: "125",
    isSelected: false
  },
  {
    id: 8,
    profile: "assets/images/users/avatar-5.jpg",
    name: "Colin Melton",
    position: "Backend Developer",
    email: "colin@skote.com",
    tags: ['Php', 'Java', 'Python'],
    project: "136",
    isSelected: false
  },
  {
    id: 9,
    name: "Mark Ellison",
    position: "Full Stack Developer",
    email: "mark@skote.com",
    tags: ['Ruby', 'Php', '2 + more'],
    project: "121",
    isSelected: false
  },
  {
    id: 10,
    profile: "assets/images/users/avatar-4.jpg",
    name: "Minnie Walter",
    position: "Frontend Developer",
    email: "minnie@skote.com",
    tags: ['Html', 'Css', '2 + more'],
    project: "145",
    isSelected: false
  },
  {
    id: 11,
    profile: "assets/images/users/avatar-5.jpg",
    name: "Shirley Smith",
    position: "UI/UX Designer",
    email: "shirley@skote.com",
    tags: ['Photoshop', 'illustrator'],
    project: "136",
    isSelected: false
  },
  {
    id: 12,
    name: "John Santiago",
    position: "Full Stack Developer",
    email: "john@skote.com",
    tags: ['Ruby', 'Php', '2 + more'],
    project: "125",
    isSelected: false
  },
  {
    id: 13,
    profile: "assets/images/users/avatar-5.jpg",
    name: "Colin Melton",
    position: "Backend Developer",
    email: "colin@skote.com",
    tags: ['Php', 'Java', 'Python'],
    project: "136",
    isSelected: false
  },
]

export { userList };
