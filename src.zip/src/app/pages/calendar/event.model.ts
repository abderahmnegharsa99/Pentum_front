// Event Data
export interface Event {
    name: string;
    value: string;
}
