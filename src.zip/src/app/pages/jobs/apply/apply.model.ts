export interface jobApplyModel {
    id: any;
    title: string;
    company: string;
    type: string;
    date: string;
    status: any;
  }
  